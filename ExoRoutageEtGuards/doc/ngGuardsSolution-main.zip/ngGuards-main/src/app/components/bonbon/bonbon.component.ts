import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bonbon',
  templateUrl: './bonbon.component.html',
  styleUrls: ['./bonbon.component.css']
})
export class BonbonComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
